var numElements = 100;
var mynums = new CArray(numElements);
print(mynums.toString());