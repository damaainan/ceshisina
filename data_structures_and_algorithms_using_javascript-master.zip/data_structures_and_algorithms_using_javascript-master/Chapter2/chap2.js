var numbers = [1,2,3,4,5];
if (Array.isArray(numbers)) {
   // perform array tasks on numbers
}
